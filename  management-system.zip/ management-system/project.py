class AlbertaHospital:
    def __init__(self):
        self.doctors = []
        self.patients = []

    def show_menu(self):
        print("Welcome to Alberta Hospital (AH) Management System")
        print("Select from the following options, or select 3 to stop:")
        print("1 - Doctors")
        print("2 - Patients")
        print("3 - Exit Program")

    def handle_menu_choice(self, choice):
        if choice == 1:
            self.show_doctors()
        elif choice == 2:
            self.show_patients()
        elif choice == 3:
            print("Program exited, Thank you for your service! ")
            exit()
        else:
            print("Invalid choice. Please try again.")

    def show_doctors(self):
        Management().__displayMenu

    def show_patients(self):
        PatientManagement().__displaymenu

    def run(self):
        while True:
            self.show_menu()
            choice = int(input("Enter your choice: "))
            self.handle_menu_choice(choice)

class Doctor:
    def __init__(self, id, name, specialist,timing, qualification, room_number):
        self.id = id
        self.name = name
        self.specialist = specialist
        self.timing = timing
        self.qualification = qualification
        self.room_number = room_number

    def __str__(self):
        
        # used the format method to align all the display 
        
        return "{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:<15}\t{:>5}\n".format(
            self.id, self.name, self.specialist, self.timing, self.qualification, self.room_number)

class DoctorsManager:
    def __init__(self):
        self.doctors = []
        self.__read_doctors_file()

    def __read_doctors_file(self):
        file = open("doctors.txt", "r")
        content = file.readlines()
        file.close()
        for line in content:
            fields = line.strip("\n").split("_")
            doctor = Doctor(fields[0], fields[1], fields[2], fields[3],  fields[4],fields[5])
            self.doctors.append(doctor)

    def display_doctor_list(self):
        for doctor in self.doctors:
            print(doctor)

    def searchByID(self):
        found = False
        id = input("Enter The Doctor's ID:\t")
        for doctor in self.doctors:
            if doctor.id == id:
                found =True
                print("\n")
                print("{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:<15}\t{:>5}\n".format("Id", "Name", "Speciality", "Timing", "Qualification", "Room Number"))
                print(doctor)
        if not found:
            print("Can't find the doctor with the same ID on the system")
            
    def SearchByName(self):
        found = False
        Name = input("Enter The Doctor's Name:\t")
        for doctor in self.doctors:
            if doctor.name == Name:
                found = True
                print("\n")
                print("{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:<15}\t{:>5}\n".format("Id", "Name", "Speciality", "Timing", "Qualification", "Room Number"))
                print(doctor)
        if not found:
            print("Can't find the doctor with the same name on the system")
            
    def add_doctor(self):
        while True:
            id = input("Enter The  Doctor's ID (must be 2 digits): ")
            if len(id) == 2 and id.isdigit():
                break
            else:
                print("Invalid ID. Please enter a 2-digit number.")

        name = input("Enter  Doctor's Name: ")
        specialist = input("Enter Doctor's Specialist: ")
        timing = input("Enter Doctor's Timing: ")
        qualification = input("Enter Doctor's Qualification: ")
        room_number = input("Enter Doctor's Room Number: ")
        doctor = Doctor(id, name, specialist, timing, qualification, room_number)
        self.doctors.append(doctor)

        # add the new doctors back to the file starting from a new line 
        with open("doctors.txt", "a") as f:
            f.write(f"{id}_{name}_{specialist}_{timing}_{qualification}_{room_number}".rstrip() + "\n")

        print(f"Doctor {name} with ID {id} has been added successfully.")
        print("\n")
        print(doctor)

        
    def edit_doctor_info(self):
        id = input("Enter Doctor's ID to edit: ")
        found = False
        for doctor in self.doctors:
            if doctor.id == id:
                found = True
                print(f"Doctor's current name is {doctor.name}. Leave blank if no change.")
                name = input("New name: ")
                
                if name:
                    doctor.name = name

                print(f"Doctor's current specialist is {doctor.specialist}. Leave blank if no change.")
                specialist = input("New specialist: ")
                if specialist:
                    doctor.specialist = specialist

                print(f"Doctor's current qualification is {doctor.qualification}. Leave blank if no change.")
                qualification = input("New qualification: ")
                if qualification:
                    doctor.qualification = qualification

                print(f"Doctor's current room number is {doctor.room_number}. Leave blank if no change.")
                room_number = input("New room number: ")
                if room_number:
                    doctor.room_number = room_number

                print("Doctor information has been updated.")
                print("\n")
                print(doctor)
                
                 # Write the updated doctor information back to the file
                with open("doctors.txt", "w") as f:
                    for doctor in self.doctors:
                        f.write(f"{doctor.id}_{doctor.name}_{doctor.specialist[0]}-{doctor.timing[1]}_{doctor.qualification}_{doctor.room_number}\n")

                break

        if not found:
            print("\n")
            print(f"Doctor {id} is invalid.")


class Management:
    def __init__(self):
        self.DoctorSManager = DoctorsManager()
        self.__displayMenu()
    def __displayMenu(self):
        option = 0
        while (option != 6):
            print('1 - Display Doctors list')
            print('2 - Search for doctor by ID')
            print('3 - Search for doctor by name')
            print('4 - Add doctor')
            print('5 - Edit doctor info')
            print("6 -Back to the Main Menu")
            option = int(input())

            if option == 1:
                self.DoctorSManager.display_doctor_list()
            elif option == 2:
                self.DoctorSManager.searchByID()
            elif option == 3:
                self.DoctorSManager.SearchByName()
            elif option == 4:
                self.DoctorSManager.add_doctor()
            elif option == 5:
                self.DoctorSManager.edit_doctor_info()
            elif option == 6:
                hospital.run() 
                
            else:
                print("Invalid Input, Please Try Again")
                
class Patient:
    def __init__(self, id, name, disease,gender, age):
        self.id = id
        self.name = name
        self.disease  = disease 
        self.gender = gender
        self.age = age

    def __str__(self):
         # used the format method to align all the display 
        return "{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:>5}\n".format(
            self.id, self.name, self.disease, self.gender, self.age)
    
    
class PatientsManager:
    def __init__(self):
        self.patients = []
        self.__read_patient_file()

    def __read_patient_file(self):
        file = open("patients.txt", "r")
        Patientcontent = file.readlines()
        file.close()
        for line in Patientcontent:
            Patientfields = line.strip("\n").split("_")
            patient = Patient(Patientfields[0], Patientfields[1], Patientfields[2], Patientfields[3], Patientfields[4] )
            self.patients.append(patient)

    def DisplayPatientList(self):
        for patient in self.patients:
            print(patient)

    def searchByID(self):
        found = False
        id = input("Enter The Patient's ID:\t")
        for patient in self.patients:
            if patient.id == id:
                found =True
                print("\n")
                print("{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:>5}\n".format("Id", "Name", "Disease", "Gender", "Age"))
                print(patient)
        if not found:
            print("Can't find the doctor with the same ID on the system")
            
    def SearchByName(self):
        found = False
        Name = input("Enter The patient's Name:\t")
        for patient in self.patients:
            if patient.name == Name:
                found = True
                print("\n")
                print("{:<7}\t{:<15}\t{:<15}\t{:<10}\t{:>5}\n".format("Id", "Name", "Disease", "Gender", "Age"))
                print(patient)
                
        if not found:
            print("Can't find the patient with the same name on the system")
            
    def AddPatient(self):
        while True:
            id = input("Enter The  Patient's ID (must be 2 digits): ")
            if len(id) == 2 and id.isdigit():
                break
            else:
                print("Invalid ID. Please enter a 2-digit number.")

        name = input("Enter  patient's Name: ")
        disease = input("Enter patient's disease: ")
        gender = input("Enter Patient's Gender: ")
        age = input("Enter Patient's Age: ")
        patient = Patient(id, name, disease, gender, age)
        self.patients.append(patient)

        # add the new doctors back to the file starting from a new line 
        with open("patients.txt", "a") as f:
            f.write(f"{id}_{name}_{disease}_{gender}_{age}".rstrip() + "\n")

        print(f"Patient {name} with ID {id} has been added successfully.")
        print("\n")
        print(patient)

        
    def EditPatientInfo(self):
        id = input("Enter Patient's ID to edit: ")
        found = False
        for patient in self.patients:
            if patient.id == id:
                found = True
                print(f"Patient's current name is {patient.name}. Leave blank if no change.")
                name = input("Enter New name: ")
                
                if name:
                    patient.name = name

                print(f"Patient's current disease is {patient.disease}. Leave blank if no change.")
                disease = input("Enter New disease: ")
                if disease:
                    patient.disease = disease

                print(f"Patient's current gender is {patient.gender}. Leave blank if no change.")
                gender = input("Enter New gender: ")
                if gender:
                    patient.gender = gender

                print(f"Patient's current age is {patient.age}. Leave blank if no change.")
                age = input("Enter New Age: ")
                if age:
                    patient.age = age

                print("Patient information has been updated.")
                print(patient)
                
                 # Write the updated doctor information back to the file
                with open("patients.txt", "w") as f:
                    for patient in self.patients:
                        f.write(f"{patient.id}_{patient.name}_{patient.disease[0]}-{patient.gender[1]}_{patient.age}\n")

                break

        if not found:
            print(f"Patient {id} is invalid.")
            
class PatientManagement:
    def __init__(self):
        self.Patient_manager = PatientsManager()
        self.__displaymenu()
    def __displaymenu(self):
        option = 0
        while (option != 6):
            print("1 - Display Patient's list")
            print('2 - Search for patient by ID')
            print('3 - Search for patient by name')
            print('4 - Add patient')
            print('5 - Edit patient info')
            print("6 -Back to the Main Menu")
            option = int(input())

            if option == 1:
                self.Patient_manager.DisplayPatientList()
            elif option == 2:
                self.Patient_manager.searchByID()
            elif option == 3:
                self.Patient_manager.SearchByName()
            elif option == 4:
                self.Patient_manager.AddPatient()
            elif option == 5:
                self.Patient_manager.EditPatientInfo()
            elif option == 6:
                hospital.run() 
                
            else:
                print("Invalid Input, Please Try Again")

                     
hospital = AlbertaHospital()
hospital.run()           